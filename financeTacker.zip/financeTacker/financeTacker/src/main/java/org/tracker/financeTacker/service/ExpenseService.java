package org.tracker.financeTacker.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.tracker.financeTacker.model.Expense;
import org.tracker.financeTacker.repository.ExpenseRepository;

@Service
public class ExpenseService {

    @Autowired
    private ExpenseRepository expenseRepository;

    public List<Expense> getAllExpense(){
        return expenseRepository.findAll();
    }

    public void saveExpense(Expense expense){
        expenseRepository.save(expense);
    } 

    public Expense getExpenseById(Long id){
        return expenseRepository.findById(id).orElse(null);
    }

    public void deleteExpenseById(Long id){
        expenseRepository.deleteById(id);;
    }
}
