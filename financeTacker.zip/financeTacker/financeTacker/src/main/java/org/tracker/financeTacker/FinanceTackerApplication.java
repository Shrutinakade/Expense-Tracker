package org.tracker.financeTacker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinanceTackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinanceTackerApplication.class, args);
	}

}
