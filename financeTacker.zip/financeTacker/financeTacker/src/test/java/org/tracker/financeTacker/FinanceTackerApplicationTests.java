package org.tracker.financeTacker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinanceTackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
